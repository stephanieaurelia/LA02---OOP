// 2540123984 - stephanie aurelia
// OOP GSLC SESSION 4 ASSIGNMENT
// ROCK PAPER SCISSORS

package sess4mar7_gslc;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;   


public class rockpaperscissors {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// set up scanner
		Scanner inp = new Scanner(System.in);
		ArrayList<String> rps = new ArrayList<String>();
		rps.add("rock");
		rps.add("paper");
		rps.add("scissors");
		
//		System.out.println(rps);
		
		// scan input
		System.out.println("< ROCK PAPER SCISSORS >");
		System.out.println("");
		System.out.println("Choose rock, paper, or scissors (all lowercase): ");
		String urps = inp.next();
		
		// generate random number
		int cidx = (int)(Math.random() *3); // multiple by 3 to get random number between 0 and 3
		String crps = rps.get(cidx); // get element from arraylist based on the index
		
		if (urps.equals(crps)) {
			System.out.println("same choice, TIE :/");
		}
		else if (urps.equals("rock")) {
			if (crps.equals("paper")) {
				System.out.println("rock < paper, YOU LOSE :<");
			}
			else {
				System.out.println("rock > scissors, YOU WIN :>");
			}
		}
		else if (urps.equals("paper")) {
			if (crps.equals("rock")) {
				System.out.println("paper > rock, YOU WIN :>");
			}
			else {
				System.out.println("paper < scissors, YOU LOSE :<");
			}
		}
		else if (urps.equals("scissors")) {
			if (crps.equals("rock")) {
				System.out.println("scissors < rock, YOU LOSE :<");
			}
			else {
				System.out.println("scissors > paper, YOU WIN :>");
			}
		}
		else {
			System.out.println("Please choose rock, paper, or scissors.");
			System.out.println("Make sure your input is in lowercase!");
		}
	}

}
